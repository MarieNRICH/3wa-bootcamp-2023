<?php

namespace App\Controllers;
// use App\Models\PostModel;
    class AboutController extends MainController {
    
}
    
?>