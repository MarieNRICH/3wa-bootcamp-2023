document.addEventListener("DOMContentLoaded", () => {

/*Récupération des références html*/
    const links = document.querySelectorAll('nav li');

/* On écoute l'évènement click sur le bouton submit*/
    icons.addEventListener("click", () => {
        nav.classList.toggle("active");
        console.log(links);
    }); 

    links.forEach((link) => {
        link.addEventListener("click", () => {
            nav.classList.remove("active");
        });
    }); 

// fonction de la slide de slick 
	$(document).ready(function () {
		$('.slider').slick({
			dots: true
		});
	});
	
/* Compteur d'inscription */
let count = 0;

document.getElementById("decreaseBtn").onclick = function(){
    count-=1;
    document.getElementById("countLabel").innerHTML = count;
};

document.getElementById("resetBtn").onclick = function(){
    count=0;
    document.getElementById("countLabel").innerHTML = count;
};

document.getElementById("increaseBtn").onclick = function(){
    count+=1;
    document.getElementById("countLabel").innerHTML = count;
};
	
	
});