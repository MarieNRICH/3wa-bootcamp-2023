# Exercice dirigé: Menu accessible

## Instructions
- Préparer une page avec plusieurs sections (minimum 3) contenant au moins 3 paragraphes et avec une ancre (ID).
- Préparer une DIV avec des liens pointant vers ces différentes ancres.
- Cacher les liens de cette DIV
- Les rendre visible quand on utilise la touche [TAB].

## Styles des éléments du menu
- padding de 1em
- couleurs: blanc sur fond noir

## Test
Lors du test, appuyer sur la touche [TAB] pour faire défiler les liens et sur la touche [ENTREE] pour executer le lien (le tout sans utiliser la souris bien sûr).
