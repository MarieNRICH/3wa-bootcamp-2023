# Exercice dirigé: Les variables CSS

Reproduire la maquette en utilisant les variables CSS.

## COULEURS
- texte : #444
- orange : #DD5735

## POLICE
- arial
- titre : 20px

Le lien renvoi sur la page de Mozilla Developer Network concernant les variables : 
https://developer.mozilla.org/fr/docs/Web/CSS/Using_CSS_custom_properties