# Exercice dirigé: La cascade

## Généralités
Marge de 2em entre les articles
Pas de marge pour les H2

## Elément CODE
Padding droite et gauche à 1em
couleur blanc sur fond #333

## Couleurs

### Ordre dans la source
purple
green

### Spécificité
blue
violet
orangered
orange
yellow

### Importance
green
red