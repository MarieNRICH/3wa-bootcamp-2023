<?php
//*******
// A REFACTORER (fonctions, découpage de fichiers etc..)
//*******

// Permet de définir la timezone pour l'heure de la date
date_default_timezone_set('Europe/Paris');

//Permet de créer un tableau de lettre de A à Z
$letters = range('A', 'Z');

// permet de créer un nombre aléatoire de 4 chiffres
$randomNumbers = mt_rand(1000, 9999);
// Génération d'un nombre aléatoire entre 1 et 1000
$randomNumberSub = random_int(1, 1000);
// Génération d'un nombre aléatoire int compris entre 1 et 10
$randomNumber = random_int(1, 10);
// Génération d'un nombre aléatoire int compris entre 1 et 3
$evilNumber = random_int(1, 3);

// permet de récupérer la date du jour au format jour/mois/année
$date = date('d/m/y');
// Deuxième façon d'afficher la date, cette fois ci avec le mois en français
$formatter = new IntlDateFormatter('fr_FR', IntlDateFormatter::LONG, IntlDateFormatter::NONE);
// premet de récupérer l'heure 
$time = date('H:i:s');


$randomNumberSentence = '';
$evilSentence = '';
$randomNumberSubSentence = '';

// Création du nom du robot de façon aléatoire
$robotName = $letters[array_rand($letters)] . $letters[array_rand($letters)] . '-' . $randomNumbers;
// Reverse le nom du robot créé précédement
$reversedRobotName = strrev($robotName);


// Trouver le nombre aléatoire via boucle 
for ($i = 1; $i <= 1000; $i++) {
    if ($randomNumberSub === $i) {
        $randomNumberSubSentence = "J'ai trouvé l nombre, c'est $i";
    }
}

// Afficher voulez vous un café 2/3
if ($evilNumber === 1) {
    $evilSentence = 'Extermination ! Extermination !';
} else {
    $evilSentence = 'Vous voulez un café ?';
}

// Déterminer si le nombre random est pair ou impair
if ($randomNumber % 2 === 0) {
    $randomNumberSentence = "le nombre $randomNumber est pair";
} else {
    $randomNumberSentence = "le nombre $randomNumber est impair";
}



// Chercher le nombre random via recherche dichotomique
$counter = 0;
function findRandomNumberDicho(int $randomNumberSub, int $start, int $end, int &$counter): string
{
    $counter++;
    echo "randomNumberSub : $randomNumberSub";
    echo "<br>";
    echo "start : $start";
    echo "<br>";
    echo "end : $end";
    echo "<br>";
    $milieu = intval(($start + $end) / 2);
    echo "<br>";
    echo "milieu : $milieu";
    if ($randomNumberSub === $milieu) {
        return 'nombre trouvé !';
    } else if ($randomNumberSub > $milieu) {
        return findRandomNumberDicho($randomNumberSub, $milieu, $end, $counter);
    } else if ($randomNumberSub < $milieu) {
        return findRandomNumberDicho($randomNumberSub, $start, $milieu, $counter);
    }
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <h2>Salut, humain. Je suis <?= $robotName ?></h2>
    <h2>Mon nom à l'envers s'écrit <?= $reversedRobotName; ?>. Ah. Ah. Ah.</h2>
    <h3>nous actuellement le <?= $date; ?> il est <?= $time; ?></h3>
    <p><?= $randomNumberSentence; ?></p>
    <h2><?= $evilSentence; ?></h2>
    <h2>Le nombre est <?= $randomNumberSubSentence; ?></h2>
    <h2><?= findRandomNumberDicho($randomNumberSub, 1, 1000, $counter); ?></h2>
    <p>Le nombre à été trouvé en <?= $counter; ?> coups</p>

</body>

</html>