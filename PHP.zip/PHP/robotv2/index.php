<?php
//*******
// A REFACTORER (fonctions, découpage de fichiers etc..)
//*******

require './functions/generic_functions.php';
require './functions/robot_functions.php';
require './views/homePage.phtml';

















?>
