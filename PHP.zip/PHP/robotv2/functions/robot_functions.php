<?php
// Création du nom du robot de façon aléatoire
if(isset($_POST['robotname']) && !empty($_POST['robotname'])){
    $robotName = $_POST['robotname'];
}else{
    $robotName = $letters[array_rand($letters)] . $letters[array_rand($letters)] . '-' . $randomNumbers;
}
// Reverse le nom du robot créé précédement
$reversedRobotName = strrev($robotName);

// Afficher voulez vous un café 2/3
if(isset($_POST['morality'])){
    $evilNumber = $_POST['morality'];    
}

if ($evilNumber == 1) {
    $evilSentence = 'Extermination ! Extermination !';
    $evilSentenceColor = 'color:red';
} else {
    $evilSentence = 'Vous voulez un café ?';
}

?>
