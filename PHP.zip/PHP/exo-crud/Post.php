<?php 


class Post{
    
    public function read(){
        try {
            $dbh = new PDO('mysql:host=db.3wa.io;dbname=simondepaix_blog', 'simondepaix', '30dc42d896d48765e5267a3c4d3e0e9e');
        } catch (PDOException $e) {
            print "Erreur !: " . $e->getMessage() . "<br/>";
            die();
        }
        $sql = "SELECT * FROM posts";
        $query = $dbh->prepare($sql);
        $query->execute();
        $posts = $query->fetchAll(PDO::FETCH_ASSOC);
        var_dump($posts);
    }
    
    public function create(){
        try {
            $dbh = new PDO('mysql:host=db.3wa.io;dbname=simondepaix_blog', 'simondepaix', '30dc42d896d48765e5267a3c4d3e0e9e');
        } catch (PDOException $e) {
            print "Erreur !: " . $e->getMessage() . "<br/>";
            die();
        }     
        $sql = 'INSERT INTO `posts`(`title`, `content`, `img`, `user_id`) 
        VALUES ("monnouvel article","test.jpg","lorem ipsum dolor sit amet","1")';
        
        $query = $dbh->prepare($sql);
        if($query->execute()){
            echo 'article créé';
        }else{
           echo 'echec';
        }
        
    }
    
    public function update(){
        try {
            $dbh = new PDO('mysql:host=db.3wa.io;dbname=simondepaix_blog', 'simondepaix', '30dc42d896d48765e5267a3c4d3e0e9e');
        } catch (PDOException $e) {
            print "Erreur !: " . $e->getMessage() . "<br/>";
            die();
        }    
        
        $sql = "UPDATE `posts` SET `title`='TEST',`content`='[value-4]',`img`='[value-5]',`user_id`='1' WHERE id = 13";
        $query = $dbh->prepare($sql);
        
        if($query->execute()){
            echo 'article mis à jour';
        }else{
           echo 'echec';
        }
    }
    
    public function delete(){
        try {
            $dbh = new PDO('mysql:host=db.3wa.io;dbname=simondepaix_blog', 'simondepaix', '30dc42d896d48765e5267a3c4d3e0e9e');
        } catch (PDOException $e) {
            print "Erreur !: " . $e->getMessage() . "<br/>";
            die();
        }    
        
        $sql = "DELETE FROM `posts` WHERE id = 13";
        $query = $dbh->prepare($sql);
        
        if($query->execute()){
            echo 'article supprimé';
        }else{
           echo 'echec';
        }
    }
    
}
/**************C.R.U.D**********************/
/******Create . Read . Update . Delete******/

$post = new Post();
$post->read();
$post->create();
$post->update();
$post->delete();