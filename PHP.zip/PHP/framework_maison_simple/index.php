<?php
/*on require les différents controllers (temporaire) */
require './Controllers/HomeController.php';
require './Controllers/AboutController.php';
require './Controllers/ContactController.php';
require './Controllers/BlogController.php';

/* on défini nos routes disponibles*/
const AVAIABLE_ROUTES = [
    'home'=>'HomeController',
    'about'=>'AboutController',
    'contact'=>'ContactController',
    'blog'=>'BlogController',
];

/* de base, la page est définie comme home*/
$page = 'home';
$controller;

if(isset($_GET['page']) && !empty($_GET['page'])){
    $page = $_GET['page'];
}

if(array_key_exists($page,AVAIABLE_ROUTES)){
    $controller = AVAIABLE_ROUTES[$page];
}else{
    $controller = 'ErrorController';
}

$controller();


?>
