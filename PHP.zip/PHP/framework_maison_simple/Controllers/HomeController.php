<?php 

function HomeController(){
    require './views/layout/header.phtml';
    require './views/partials/home.phtml';
    require './views/layout/footer.phtml';    
}


?>