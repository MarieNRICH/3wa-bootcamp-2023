<?php

require 'Feline.php';
require 'Cat.php';
$cat = new Cat('Jean','noir',3,true);

var_dump($cat);
$cat->presentation();
