<?php


class Calculator
{
    public function addition( $nb1, $nb2){
        return ($nb1 + $nb2);
    }
    
    public function subtract( $nb1, $nb2){
        return ($nb1 - $nb2);
    }
    
    public function multiply( $nb1, $nb2){
        return ($nb1 * $nb2);
    }
    
    
}