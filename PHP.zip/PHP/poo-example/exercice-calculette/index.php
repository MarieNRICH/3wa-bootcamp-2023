<?php 

/*on require le fichier qui contient le code de la classe*/
require 'Calculator.php';

/* On créer une nouvelle instance (un nouvel objet) de Calculator*/
$calc = new Calculator();

/* la variable qui va contenir le résultat. De base le résultat est null lorsqu'on arrive sur la page*/
$result = null;

/*Si la variable $_POST n'est pas vide, c'est que le formulaire à été soumis*/
if(!empty($_POST)){
    
/* Si nb1, nb2 ne sont pas vide, c'est qu'ils ont une valeur qui à été soumise par le form*/
if(!empty($_POST['nb1']) && !empty($_POST['nb2']))    {
    
    /* Si l'opérateur  est + j'appelle la méthode addition de mon objet*/
        if($_POST['operator'] === '+'){
            $result = $calc->addition($_POST['nb1'],$_POST['nb2']);
        }
        else  if($_POST['operator'] === '-'){
            
            $result =  $calc->subtract($_POST['nb1'],$_POST['nb2']);
            
        }else  if($_POST['operator'] === '*'){
            
             $result = $calc->multiply($_POST['nb1'],$_POST['nb2']);
             
        }
    }
    
}

?>


<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    
    <form action="" method="post">
        <input type="number" name="nb1"/>
        <input type="number" name="nb2"/>
        <select name="operator" id="">
            <option value="+">+</option>
            <option value="-">-</option>
            <option value="*">*</option>
        </select>
        <input type="submit" value="Submit"/>
    </form>
    <!-- Si $result est différent de null c'est qu'il y'a un résultat de calcul-->
    <?php if($result != null): ?>
    
    <!--On affiche le résultat-->
    <h2>Le résultat est : <?= $result; ?></h2>
    
    <!-- on affiche le calcul-->
    <h3>Le calcul est <?= $_POST['nb1'] ?> <?= $_POST['operator'] ?> <?= $_POST['nb2']; ?></h3>
    <?php endif; ?>
</body>
</html>