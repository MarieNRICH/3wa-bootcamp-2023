<?php 

class ContactController extends MainController{

}