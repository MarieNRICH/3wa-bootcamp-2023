<?php

class HomeController extends MainController{

}