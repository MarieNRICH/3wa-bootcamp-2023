<?php

$_POST = [
    'username'=>'simon',
    'userage'=>25
]
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    
    <form action="" method="post">
        <input type="text" name="username" placeholder="votre nom"/>
        <input type="number" name="userage"placeholder="votre age" />
        <input type="submit" value="Submit"/>
    </form>
    
    
    <?php if(isset($_POST['username']) && !empty($_POST['username'])):?>
    
        <h2>Bonjour,<?= $_POST['username']; ?> </h2>
        
    <?php endif; ?>
    
    <?php if(isset($_POST['userage']) && !empty($_POST['userage'])):?>
    
        <h2>Vous avez <?= $_POST['userage']; ?> ans</h2>
        
    <?php endif; ?>
    
</body>
</html>