<?php 

if(!empty($_POST)){
    if(!empty($_POST['number1']) && !empty($_POST['number2']) && !empty($_POST['operatorSelector'])){
        $number1 = $_POST['number1'];
        $number2 = $_POST['number2'];
        $operator = $_POST['operatorSelector'];
        
       if($operator === '+'){
           echo 'resultat : ' . ($number1 + $number2);
       }else  if($operator === '-'){
           echo 'resultat : ' . ($number1 - $number2);
       }else  if($operator === '*'){
           echo 'resultat : ' . ($number1 * $number2);
       } else{
           echo 'resultat : ' . $number1 / $number2;
       }
    }
}

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    
    <form action="" method="post">
        <input type="texte" name="number1"/>
        <input type="number" name="number2"/>
        <select name="operatorSelector">
            <option value="+">+</option>
            <option value="-">-</option>
            <option value="/">/</option>
            <option value="*">*</option>
        </select>
        <input type="submit" value="Submit"/>
    </form>
</body>
</html>