<?php
/*affichage de la liste des cookies*/
var_dump($_COOKIE);
/*si la variable $_POST n'est pas vide c'est qu'on à soumis le form*/
if(!empty($_POST)){
    /* si la variable $_POST contient la clé correspondant au name du select, c'est qu'il à été sélectionné*/
    if(!empty( $_POST['cookieSelector'])){
        $selectedData = $_POST['cookieSelector'];
        /* on supprime le cookie en ajoutant une date d'expiration antérieur au temps actuel*/
        setcookie($selectedData,'',time() - 3600);
    }
}
?>

<form action="" method="post">
    <select name="cookieSelector">
        <!--ici on boucle sur la variable $_COOKIE qui contient la liste de tous les cookies-->
        <?php foreach($_COOKIE as $key => $cookie): ?>
        <!-- à chaque itération de la boucle on créé une option avec la clé en valeur (pour la transmettre dans le $_POST -->
            <option value='<?= $key; ?>'><?= $key; ?></option>
        <?php endforeach; ?>
    </select>
    <input type="submit" value="Submit"/>
</form>
