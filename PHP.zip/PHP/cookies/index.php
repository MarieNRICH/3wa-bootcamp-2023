<?php

/*test si $_POST n'est pas vide, signifie que le form est envoyé*/
if(!empty($_POST)){
    /*est-ce que le champs username n'est pas vide*/
    if(!empty($_POST['username'])){
        /*je stock la valeur du champs username*/
        $userName = $_POST['username'];
        /*création du cookie nom, valeur, temps*/
        setcookie('username',filter_var( $userName, FILTER_SANITIZE_SPECIAL_CHARS ),time()+86400);
        echo '<p>Cookie Créé !</p>';
    }
}


?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <form action="" method="post">
        <input type="text" name="username"/>
        <input type="submit" value="Submit"/>
    </form>
    <a href="cookie_manage.php">gestion des cookies</a>
    <a href="welcome.php">accueil</a>
</body>
</html>