<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <!-- si le cookie est non null et non vide -->
    <?php if(isset($_COOKIE['username']) && !empty($_COOKIE['username'])): ?>
    <!-- on affiche bonjour + username-->
        <h1>Bonjour, <?= $_COOKIE['username']; ?></h1>
    <?php else: ?>
        <h1>Il n'y a pas de cookies actuellement</h1>
    <?php endif; ?>
    <a href="cookie_manage.php">gestion des cookies</a>
    <a href="index.php">formulaire</a>
</body>
</html>