<?php 


class Post{
    
    public function connection(){
        try {
            $pdo = new PDO('mysql:host=db.3wa.io;dbname=simondepaix_blog', 'simondepaix', '30dc42d896d48765e5267a3c4d3e0e9e');
        } catch (PDOException $e) {
            print "Erreur !: " . $e->getMessage() . "<br/>";
            die();
        }    
        return $pdo;
        
    }
    
    public function read(){
        
        $pdo = $this->connection();
        $sql = "SELECT * FROM posts";
        $query = $pdo->prepare($sql);
        $query->execute();
        $posts = $query->fetchAll(PDO::FETCH_ASSOC);
        var_dump($posts);
    }
    
    public function create($values){
        $pdo = $this->connection(); 
        
        $sql = 'INSERT INTO `posts`(`title`, `content`, `img`, `user_id`) 
        VALUES (:title,:img,:content,:user_id)';
        
        $query = $pdo->prepare($sql);
        if($query->execute($values)){
            echo 'article créé';
        }else{
           echo 'echec';
        }
        
    }
    
    public function update(){
        $pdo = $this->connection();
        
        $sql = "UPDATE `posts` SET `title`='TEST',`content`='[value-4]',`img`='[value-5]',`user_id`='1' WHERE id = 13";
        $query = $pdo->prepare($sql);
        
        if($query->execute()){
            echo 'article mis à jour';
        }else{
           echo 'echec';
        }
    }
    
    public function delete(){
        $pdo = $this->connection();
        
        $sql = "DELETE FROM `posts` WHERE id = 13";
        $query = $pdo->prepare($sql);
        
        if($query->execute()){
            echo 'article supprimé';
        }else{
           echo 'echec';
        }
    }
    
}
/**************C.R.U.D**********************/
/******Create . Read . Update . Delete******/

$post = new Post();
$post->read();
$values = [
    'title'=>'test',
    'img'=>'test',
    'content'=>'test',
    'user_id'=>'1',
];
$post->create($values);
$post->update();
$post->delete();