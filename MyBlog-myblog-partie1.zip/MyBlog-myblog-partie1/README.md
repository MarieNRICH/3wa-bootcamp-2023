# Ce TP à pour but d'introduire au concept MVC et POO en php. Nous allons créer un blog en partant d'une base bootstrap.

# MyBlog partie 1
# consignes : vous allez devoir découper la maquette  et créer l'architecture de notre dossier correspondant à celui ci :
     racine
    ├── app
    │     ├── Controllers
    │     │     
    │     │     
    │     │     
    │     ├── Models
    │     │    
    │     │    
    │     ├── views
    │     │     ├─
    │     │     │  
    │     │     │  
    │     │     │  
    │     │     │  
    │     │     │  
    │     │     │    
    │     │     │    
    │     │     └── front
    │     │           ├── partials
    │     │           │     ├── 
    │     │           │     └── 
    │     │           ├── layouts
    │     │                 └── 
    │     │           
    │     │           
    │     │           
    │     └── Utils
    ├── public
    │     ├── assets
    │     │     └── css
    │     │           └── styles.css
    │     └── index.php
             
