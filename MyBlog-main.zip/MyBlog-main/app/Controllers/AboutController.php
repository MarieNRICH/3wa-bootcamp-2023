<?php

namespace App\Controllers;

class AboutController extends MainController
{
}
