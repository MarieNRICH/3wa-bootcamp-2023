# Ce TP à pour but d'introduire au concept MVC et POO en php. Nous allons créer un blog en partant d'une base bootstrap.

# MyBlog partie 20
## consignes : 
Cette partie à pour but de réfactorer tout ce qui à été fait jusqu'ici.

### Comment faire fonctionner notre framework
- Créer un fichier config.ini dans le dossier app/ avec les informations de la bdd
- dans le terminal, lancer <code>composer install</code>
- vérifier que le fichier composer.json correspond à vos informations
- puis dans le terminal lancer <code>composer dump-autoload</code>