<?php

class Calculator{
    
    public function addition(float $n1,float $n2):float {
        // return $this->n1 + $this->n2;
        return ($n1 + $n2);
    }

    public function substract(float $n1,float $n2):float {
        return ($n1 - $n2);
    }
    
    public function multiple(float $n1,float $n2):float {
        return ($n1 * $n2);
    }
    
    // public function presentation(){
    //     echo $this->n1.'';
    // }
}
