<?php

class Voiture implements Vehicule{
    public function 
}

?>
