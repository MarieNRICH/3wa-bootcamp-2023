<?php 

interface Vehicule{
    
    public function demarrer();
    
    public function stop();
    
}

