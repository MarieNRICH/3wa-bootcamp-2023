<?php

interface Vehicule{
    
}

?>
