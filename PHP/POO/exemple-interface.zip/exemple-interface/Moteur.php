<?php

trait Moteur{

    public function combustion(){
        return 'combustion !';
    }
    
}