<?php 
function ContactController(){
    require './views/layout/header.phtml';
    require './views/partials/contact.phtml';
    require './views/layout/footer.phtml';
}
?>