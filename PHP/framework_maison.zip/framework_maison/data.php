<?php
$articles = [
    [
        'titre' => 'Article 1',
        'auteur' => 'Auteur 1',
        'contenu' => 'Contenu de l\'article 1...'
    ],
    [
        'titre' => 'Article 2',
        'auteur' => 'Auteur 2',
        'contenu' => 'Contenu de l\'article 2...'
    ],
    [
        'titre' => 'Article 3',
        'auteur' => 'Auteur 3',
        'contenu' => 'Contenu de l\'article 3'
    ]
];

?>