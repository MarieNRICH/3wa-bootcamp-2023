<?php


function BlogModel(){
    require 'data.php';
    return $articles; 
    
}