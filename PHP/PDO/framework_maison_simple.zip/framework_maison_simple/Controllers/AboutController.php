<?php 

function AboutController(){
    require './views/layout/header.phtml';
    require './views/partials/about.phtml';
    require './views/layout/footer.phtml';
}
?>