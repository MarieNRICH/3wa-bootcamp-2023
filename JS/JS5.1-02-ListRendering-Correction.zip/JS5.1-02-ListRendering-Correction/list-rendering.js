new Vue({
    el: '#app',

    data() {
        return {
            items: ['item 1', 'item 2', 'item 3', 'item 4'],
        };
    },
});
