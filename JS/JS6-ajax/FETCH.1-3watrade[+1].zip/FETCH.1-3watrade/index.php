<?php
$conx='marienoellerichmond_3watrade';
$bd='db.3wa.io';
$user = 'marienoellerichmond';
$pass = '34fc2f0dca51a55ce29a733674c5e435';
try {
    $dsn = new PDO("mysql:host=$bd;dbname=$conx", $user, $pass, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
} catch (Exception $e) {
    die ("Erreur !: ") . $e->getMessage() . "<br/>";
    ;
}
$sql = "SELECT * FROM  products ";
$query = $dsn->prepare($sql);
$query->execute();
$products = $query->fetchAll();

if($products){
    echo json_encode($products);
}else{
    echo "Il n'y a pas de produits";
}

?>