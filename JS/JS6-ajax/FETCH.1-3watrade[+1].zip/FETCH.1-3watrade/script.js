    let btn = document.getElementById('submitBtn');
    btn.addEventListener("click", (event) => {
        event.preventDefault();
    
    fetch('index.php')
    .then(response => response.json())
    .then((data) => {
            console.log(data);
        });
    });