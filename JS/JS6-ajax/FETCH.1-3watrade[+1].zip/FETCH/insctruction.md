
----- exercice 1 fetch -----
utilisez fetch pour récupérer des informations via une des api suivante :
https://www.themealdb.com/api.php
https://www.thecocktaildb.com/api.php

Vous devez créer un champs texte avec un bouton submit
lors du clic, récupérer la valeur du champs et la transmettre à l'url
lors de la réponse, mettre en forme les résultat, vous pouvez utiliser une carte bootstrap
 
Free Meal API | TheMealDB.com