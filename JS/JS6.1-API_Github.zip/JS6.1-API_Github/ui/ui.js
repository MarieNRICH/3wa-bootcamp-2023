import { dateDiffInDays, deleteCardIf } from '../utilities/utilities.js';

function showUser(user) {
}

export default showUser;
