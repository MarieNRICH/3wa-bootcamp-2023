#### Exercises : 

##### GET 
En utilisant les modules, `fetch` et `async` / ` await`, et l'url suivante : 'https://api.github.com/users/USER_NAME' ou USER_NAME 
est un nom d'utilisateur github.  
Envoyer une requête avec un formulaire pour récupérer les informations d'un utilisateur et les afficher sur une page.  
Afficher le nom d'utilisateur.  
Afficher le nombre de repos public.   
Afficher l'avatar.   
Afficher la date de création du compte et la différence en jour depuis aujourd'hui.  
Gérer les erreurs et notifier l'utilisateur le cas échéant.
