function dateDiffInDays(date) {
	
}

function deleteCardIf(card) {
	
}

export { dateDiffInDays, deleteCardIf };
