new Vue({
    el: '#app',
    data() {
        return {
            email: '',
            password: '',
            phone: '',
        };
    },
});
