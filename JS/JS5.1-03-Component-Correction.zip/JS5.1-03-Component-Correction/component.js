import MyComponent from './MyComponent.js';
new Vue({
    el: '#app',
    //Ajouter le nom du composant.
    components: { MyComponent },
    data: {},
});
