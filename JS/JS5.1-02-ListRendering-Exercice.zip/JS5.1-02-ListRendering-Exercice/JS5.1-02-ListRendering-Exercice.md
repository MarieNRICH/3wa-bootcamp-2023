# Exercice List Rendering

Créer un objet data contenant un tableau simple et un tableau composé d'objets

Afficher les éléments de l'objet data dans des listes et tables

```javascript
<script src="https://cdn.jsdelivr.net/npm/vue/dist/vue.js"></script>
new Vue({
    el: '#app',
    // <!-- Créer un objet data contenant un tableau simple et un tableau composé d'objet  -->
    
    // <!-- Afficher les éléments de l'objet data dans des listes et tables   -->
});
```
