<?php 

namespace App\Controllers;


class ContactController extends MainController{

}