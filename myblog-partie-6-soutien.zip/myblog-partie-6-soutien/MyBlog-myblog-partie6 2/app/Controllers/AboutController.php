<?php 

class AboutController extends MainController{

}